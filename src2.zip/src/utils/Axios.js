const axios = require('axios');
//const system = require('system')
import system from "./System"
axios.defaults.baseURL = '/pinmao'
var http = {
	base:axios.defaults.baseURL,
	get: function(url,params,fun) {
		axios.get(url,{params:params})
			.then(function(response) {
				fun(response);
			})
			.catch((error)=>{
				console.log(error);
				system.notice.message('操作失败/网络异常','error');
				//调用dialog
			})
			.then(function() {
				//调用dialog
			});
	}
}
export default http
