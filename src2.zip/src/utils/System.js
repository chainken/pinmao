import Notice from "./Notice.js"
var system = {
	notice:Notice
}
export default system