class TCategory{
	constructor(categoryId,categoryName,children,parentId) {
	    this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.children = children;
		this.parentId = parentId;
	}	
}
export default TCategory;