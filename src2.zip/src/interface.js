var urls = {
	products:"productlist.htm",
	saveorupdatecategory:"category/saveorupdatecategory.htm",
	findallcategory:"category/findallcategory.htm",
	deletecategory:"category/deletecategory.htm",
	insertproduct:"/product/insert.htm",
	findallproducts:"product/findAll.htm",
	deleteproduct:"product/delete.htm",
	insertnews:"news/insert.htm",
	findallnews:"news/findall.htm",
	deletenews:"news/delete.htm",
	uploadfile:"upload/file.htm"
}
export default urls;